package christmasPastryShop.core.interfaces;

public interface Engine {
    void run();
}
